#include <iostream>
#include <graphics.h>
#include <sstream>

using namespace std;

// Defining TreeNode structure
struct TreeNode {
    int value;
    TreeNode* left;
    TreeNode* right;
};

// BST Insertion
TreeNode* insertBST(TreeNode* root, int value) {
    if (root == NULL) {
        TreeNode* newNode = new TreeNode;
        newNode->value = value;
        newNode->left = NULL;
        newNode->right = NULL;
        return newNode;
    }
    if (value < root->value) {
        cout << "Inserting " << value << " to the left of " << root->value << endl;
        root->left = insertBST(root->left, value);
    } else {
        cout << "Inserting " << value << " to the right of " << root->value << endl;
        root->right = insertBST(root->right, value);
    }
    return root;
}

// AVL Tree Insertion
int height(TreeNode* node) {
    if (node == NULL) return 0;
    return max(height(node->left), height(node->right)) + 1;
}

TreeNode* rotateRight(TreeNode* y) {
    TreeNode* x = y->left;
    TreeNode* T2 = x->right;

    x->right = y;
    y->left = T2;

    return x;
}

TreeNode* rotateLeft(TreeNode* x) {
    TreeNode* y = x->right;
    TreeNode* T2 = y->left;

    y->left = x;
    x->right = T2;

    return y;
}

int getBalance(TreeNode* node) {
    if (node == NULL) return 0;
    return height(node->left) - height(node->right);
}

TreeNode* insertAVL(TreeNode* node, int value) {
    if (node == NULL) {
        TreeNode* newNode = new TreeNode;
        newNode->value = value;
        newNode->left = NULL;
        newNode->right = NULL;
        return newNode;
    }
    if (value < node->value) {
        cout << "Inserting " << value << " to the left of " << node->value << endl;
        node->left = insertAVL(node->left, value);
    } else {
        cout << "Inserting " << value << " to the right of " << node->value << endl;
        node->right = insertAVL(node->right, value);
    }

    int balance = getBalance(node);

    if (balance > 1 && value < node->left->value) {
        return rotateRight(node);
    }
    if (balance < -1 && value > node->right->value) {
        return rotateLeft(node);
    }
    if (balance > 1 && value > node->left->value) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    if (balance < -1 && value < node->right->value) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

// Search Functionality
TreeNode* search(TreeNode* root, int value) {
    if (root == NULL || root->value == value) {
        return root;
    }
    if (value < root->value) {
        return search(root->left, value);
    } else {
        return search(root->right, value);
    }
}

// Deletion Functionality
TreeNode* findMin(TreeNode* node) {
    while (node->left != NULL) node = node->left;
    return node;
}

TreeNode* deleteNode(TreeNode* root, int value) {
    if (root == NULL) return root;

    if (value < root->value) {
        root->left = deleteNode(root->left, value);
    } else if (value > root->value) {
        root->right = deleteNode(root->right, value);
    } else {
        if (root->left == NULL) {
            TreeNode* temp = root->right;
            delete root;
            return temp;
        } else if (root->right == NULL) {
            TreeNode* temp = root->left;
            delete root;
            return temp;
        }

        TreeNode* temp = findMin(root->right);
        root->value = temp->value;
        root->right = deleteNode(root->right, temp->value);
    }
    return root;
}

// Traversal Functionality
void inorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    inorderTraversal(root->left);
    cout << root->value << " ";
    inorderTraversal(root->right);
}

void preorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    cout << root->value << " ";
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}

void postorderTraversal(TreeNode* root) {
    if (root == NULL) return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    cout << root->value << " ";
}

// Print Tree (BST and AVL)
void printTree(int x, int y, TreeNode* treeNode) {
    if (treeNode == NULL) return;

    // Convert value to string
    ostringstream str1;
    str1 << treeNode->value;
    string str2 = str1.str();
    char* str = new char[str2.length() + 1];
    strcpy(str, str2.c_str());

    // Draw the node circle
    setcolor(YELLOW);
    setlinestyle(SOLID_LINE, 0, THICK_WIDTH); // Increase line thickness
    circle(x, y, 25); // Increase circle size
    floodfill(x, y, YELLOW);

    // Display the node value
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2); // Increase text size
    outtextxy(x - 10, y - 10, str);

    // Set color for lines
    setcolor(WHITE);

    // Draw lines and recursively draw subtrees
    if (treeNode->left != NULL) {
        line(x, y, x - 50, y + 50);
        printTree(x - 50, y + 50, treeNode->left);
    }
    if (treeNode->right != NULL) {
        line(x, y, x + 50, y + 50);
        printTree(x + 50, y + 50, treeNode->right);
    }

    delete[] str; // Clean up dynamically allocated memory for str
}

// Heap Insertion
void heapifyUp(int heap[], int index) {
    if (index == 0) return;
    int parent = (index - 1) / 2;
    if (heap[parent] > heap[index]) {
        swap(heap[parent], heap[index]);
        heapifyUp(heap, parent);
    }
}

void insertHeap(int heap[], int& size, int value) {
    heap[size] = value;
    cout << "Inserting " << value << " into the heap" << endl;
    heapifyUp(heap, size);
    size++;
}

// Heap Deletion
void heapifyDown(int heap[], int size, int index) {
    int smallest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < size && heap[left] < heap[smallest]) {
        smallest = left;
    }
    if (right < size && heap[right] < heap[smallest]) {
        smallest = right;
    }
    if (smallest != index) {
        swap(heap[smallest], heap[index]);
        heapifyDown(heap, size, smallest);
    }
}

void deleteHeap(int heap[], int& size, int value) {
    int index = -1;
    for (int i = 0; i < size; ++i) {
        if (heap[i] == value) {
            index = i;
            break;
        }
    }
    if (index == -1) {
        cout << "Value " << value << " not found in the heap." << endl;
        return;
    }

    cout << "Deleting " << value << " from the heap" << endl;
    heap[index] = heap[size - 1];
    size--;
    heapifyDown(heap, size, index);
}

// Print Heap
void printHeap(int heap[], int size, int x, int y, int index) {
    if (index >= size) return;

    // Convert value to string
    ostringstream str1;
    str1 << heap[index];
    string str2 = str1.str();
    char* str = new char[str2.length() + 1];
    strcpy(str, str2.c_str());

    // Draw the node circle
    setcolor(YELLOW);
    setlinestyle(SOLID_LINE, 0, THICK_WIDTH); // Increase line thickness
    circle(x, y, 25); // Increase circle size
    floodfill(x, y, YELLOW);

    // Display the node value
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2); // Increase text size
    outtextxy(x - 10, y - 10, str);

    // Set color for lines
    setcolor(WHITE);

    // Calculate left and right child indices
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    // Draw lines and recursively draw subtrees
    if (left < size) {
        line(x, y, x - 50, y + 50);
        printHeap(heap, size, x - 50, y + 50, left);
    }
    if (right < size) {
        line(x, y, x + 50, y + 50);
        printHeap(heap, size, x + 50, y + 50, right);
    }

    delete[] str; // Clean up dynamically allocated memory for str
}

void printNotesAndGuidelines(const string& structure) {
    if (structure == "BST") {
        cout << "Binary Search Tree (BST) is a data structure that maintains the following properties:\n";
        cout << "1. Every node has at most two children (left and right child).\n";
        cout << "2. The left subtree of a node contains only nodes with values less than the node's value.\n";
        cout << "3. The right subtree of a node contains only nodes with values greater than the node's value.\n";
        cout << "4. Both left and right subtrees are also BSTs.\n";
        cout << "BST provides efficient search, insert, and delete operations with average time complexities of O(log n).\n";
    } else if (structure == "Heap") {
        cout << "Min-Heap is a binary tree data structure where each parent node is smaller than its children.\n";
        cout << "Heap is typically used to implement priority queues and provides efficient insert, delete, and search operations.\n";
        cout << "Insertion and deletion in Heap have time complexities of O(log n), while searching has O(n) complexity.\n";
    } else if (structure == "AVL") {
        cout << "AVL Tree is a self-balancing Binary Search Tree (BST) where the difference between heights of left and right subtrees cannot be more than one for all nodes.\n";
        cout << "It provides efficient search, insert, and delete operations with average time complexities of O(log n) and ensures that the tree remains balanced.\n";
    }
}

int main() {
    int choice;
    cout << "Choose the structure to visualize:\n";
    cout << "1. AVL Tree\n2. BST\n3. min_Heap\n";
    cin >> choice;

    if (choice == 3) { // Heap
        int heap[100];
        int heapSize = 0;
        int size;
        cout << "Enter the number of nodes: ";
        cin >> size;

        cout << "Enter the values of the nodes:\n";
        int value;
        for (int i = 0; i < size; ++i) {
            cin >> value;
            insertHeap(heap, heapSize, value);
        }

        printNotesAndGuidelines("Heap"); // Print heap guidelines

        int op;
        do {
            cout << "\nChoose an operation:\n";
            cout << "1. Search\n2. Delete\n3. Exit\n";
            cin >> op;

            switch (op) {
                case 1: {
                    cout << "Enter the value to search: ";
                    cin >> value;
                    bool found = false;
                    for (int i = 0; i < heapSize; ++i) {
                        if (heap[i] == value) {
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        cout << "Value " << value << " found in the heap.\n";
                    } else {
                        cout << "Value " << value << " not found in the heap.\n";
                    }
                    break;
                }
                case 2: {
                    cout << "Enter the value to delete: ";
                    cin >> value;
                    deleteHeap(heap, heapSize, value);
                    break;
                }
                case 3: {
                    break;
                }
                default: {
                    cout << "Invalid choice! Please choose again.\n";
                    break;
                }
            }
        } while (op != 3);

        int gd = DETECT, gm;
        initgraph(&gd, &gm, NULL); // Use nullptr for default path

        printHeap(heap, heapSize, 300, 100, 0); // Start drawing from root node

        getch(); // Wait for a key press
        closegraph(); // Close the graphics mode

    } else { // BST or AVL
        int size;
        cout << "Enter the number of nodes: ";
        cin >> size;

        TreeNode* root = NULL;
        int value;
        cout << "Enter the values of the nodes:\n";
        for (int i = 0; i < size; ++i) {
            cin >> value;
            if (choice == 1) {
                cout << "Inserting into AVL Tree:\n";
                root = insertAVL(root, value); // AVL Tree
            } else {
                cout << "Inserting into BST:\n";
                root = insertBST(root, value); // BST
            }
        }

        if (choice == 1) {
            printNotesAndGuidelines("AVL"); // Print AVL guidelines
        } else {
            printNotesAndGuidelines("BST"); // Print BST guidelines
        }

        int op;
        do {
            cout << "\nChoose an operation:\n";
            cout << "1. Search\n2. Delete\n3. Inorder Traversal\n4. Preorder Traversal\n5. Postorder Traversal\n6. Exit\n";
            cin >> op;

            switch (op) {
                case 1: {
                    cout << "Enter the value to search: ";
                    cin >> value;
                    TreeNode* searchResult = search(root, value);
                    if (searchResult != NULL) {
                        cout << "Value " << value << " found in the tree.\n";
                    } else {
                        cout << "Value " << value << " not found in the tree.\n";
                    }
                    break;
                }
                case 2: {
                    cout << "Enter the value to delete: ";
                    cin >> value;
                    root = deleteNode(root, value);
                    cout << "Value " << value << " deleted from the tree.\n";
                    break;
                }
                case 3: {
                    cout << "Inorder Traversal: ";
                    inorderTraversal(root);
                    cout << endl;
                    break;
                }
                case 4: {
                    cout << "Preorder Traversal: ";
                    preorderTraversal(root);
                    cout << endl;
                    break;
                }
                case 5: {
                    cout << "Postorder Traversal: ";
                    postorderTraversal(root);
                    cout << endl;
                    break;
                }
                case 6: {
                    break;
                }
                default: {
                    cout << "Invalid choice! Please choose again.\n";
                    break;
                }
            }
        } while (op != 6);

        int gd = DETECT, gm;
        initgraph(&gd, &gm, NULL); // Use nullptr for default path

        printTree(300, 100, root); // Start drawing from root node

        getch(); // Wait for a key press
        closegraph(); // Close the graphics mode
    }

    return 0;
}

